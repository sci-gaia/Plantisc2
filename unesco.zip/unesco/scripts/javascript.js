$(document).ready(function(){
    $("table.st tr:nth-child(even)").addClass("stripe");
    $("#datepicker").datepicker({ autoSize: true, changeYear: true, yearRange: '1950:2015', dateFormat: 'yy-mm-dd'});
    $("#datepicker2").datepicker({ autoSize: true, changeYear: true, yearRange: '1950:2015', dateFormat: 'yy-mm-dd'});
	$.get("ajax_calls.php", {type:"unread"}, function(data){
		$("input#unread").val(data);
	});
});
   
// loading duration of courses for proper selection
function load_level(){
    dept = $("select#dept").val();
    $.post("ajax_calls.php",{dept: dept,get_duration: dept}, function(data){
	
	$("span#level").html( data);
     
    });
}

//checks the form for downloading transcripts
function transcript(){
	var check = new Boolean(true);
	if (!checkRegNum($("input#reg_num").val())){
		$("div#reg_num").html("**");
		check = false;
	} else {
		$("div#reg_num").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	
	return check;
}

//checks the form for adding courses
function validate_addCourse(){
	var check = new Boolean(true);
	var courseCode = $("input#code").val();
	if (checkCourseCode(courseCode)){
		$("div#code").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	} else {
		$("div#code").html("**");
		check = false;
	}
	if ($("#txttitle").val() == ""){
		$("div#title").html("**");
		check = false;
	} else {
		$("div#title").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if ($("input#unit").val() == ""){
		$("div#unit").html("**");
		check = false;
	} else {
		if ($("input#unit").val().length > 1){
			$("div#unit").html("**");
			check = false;
		} else {
			$("div#unit").html("&nbsp;&nbsp;&nbsp;&nbsp;");
		}
	}
	if ($("#semester").val() == 1 || $("#semester").val() == 2){
		$("div#sem").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	} else {
		$("div#sem").html("**");
		check = false;
	}
	return check;
}

//checks approval of a course
function validate_courseApproval(){
	if (!checkCourseCode($("#selcourse").val())){
		alert("Please select the course you want to approve.");
		//$("div#ccode").html("**");
		return false;
	} else {
		$("div#ccode").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if (isNaN($("#sellevel").val())){
		alert("Please select the level for the course.");
		//$("div#level").html("**");
		return false;
	} else {
		$("div#level").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	return true;
}

//checks the course allocation form for error
function validate_courseAllocate(){
	var check = new Boolean(true);
	if (!checkCourseCode($("#selcourse2").val())){
		$("div#ccode2").html("**");
		check = false;
	} else {
		$("div#ccode2").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if (isNaN($("#selstaff").val)){
		$("div#staff").html("**");
		check = false;
	} else {
		$("div#staff").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if (isNaN($("#seldepartment").val)){
		$("div#dept").html("**");
		check = false;
	} else {
		$("div#dept").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	/*if (!checkASession($("#selsession").val())){
		$("div#session").html("**");
		check = false;
	} else {
		$("div#session").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}*/
	return check;
}

//checks the student selection form
function validate_stdSel(){
	if ($("input#reg_num").val() != ""){
		var regNo = $("input#reg_num").val();
		if (checkRegNum(regNo)){
			return true;
		} else {
			$("div#reg_num").html("**");
			return false;
		}
	} else {
		$("div#reg_num").html("**");
		return false;
	}
}

//checks for password verification
function validate_admin(){
	var check = new Boolean(true);
	if ($("input#username").val() == ""){
		$("div#username").html("**");
		check = false;
	} else {
		$("div#username").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if ($("input#password").val() == ""){
		$("div#password").html("**");
		$("div#vpassword").html("**");
		return false;
	} else {
		$("div#password").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if ($("input#password").val() != $("input#vpassword").val()){
		alert("The passwords do not match!");
		$("div#password").html("**");
		$("div#vpassword").html("**");
		$("input#password").val("");
		$("input#vpassword").val("");
		check = false;
	} else {
		$("div#password").html("&nbsp;&nbsp;&nbsp;&nbsp;");
		$("div#vpassword").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	return check;
}

function validate_profile(){
	if ($("input#s_name").val() == ""){
		$("div#s_name").html("**");
		document.edit_profile.s_name.focus();
		return false;
	} else {
		$("div#s_name").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if ($("input#f_name").val() == ""){
		$("div#f_name").html("**");
		document.edit_profile.f_name.focus();
		return false;
	} else {
		$("div#f_name").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	return true;
}

/*
 *Validate the messaging form
 *
 */
//This function validates the sending of messages
function validate_send(){
	if (document.newMsgForm.to.value == ''){
		alert("Your message must have a recipient");
		document.newMsgForm.to.focus();
		return false;
	} else if (!validate_body()){
		return false;
	} else {
		return true;
	}
}
//This function validates the saving of messages
function validate_save(){
	return validate_body();
}
//This function validates the body of messages for both sending and saving
function validate_body() {
	if (document.newMsgForm.body.value == '') {
		alert("Your message must have a body.");
		document.newMsgForm.body.focus();
		return false;
    } 
	return true;		
}



//prompt during message deletion
function deleteMsg(id, from) {
	if(confirm("Are you sure u want to delete this message?")) {
		$.get("msg_handle.php", {id:id, opt:"delete", from:from}, function(){});
	}
}	

function msgToAll(){
	$.get("ajax_calls.php", {type:"msg"}, function(data){
		$("#to").val(data);
	});
}


// loading the lgas belonging to a particular state
function get_lga(){
    //alert("i got your call");
    states = $("select#states").val();
    states = $("select#states").val();
    $.post("ajax_calls.php",{states: states, get_lga: states}, function(data){
	
	$("select#lga").html( data);
     
    });
}

function c_admin(){
   //alert("make it happen");
   dept_id = $("select#c_a_dept").val();
   $.post("ajax_calls.php",{c_admin: dept_id}, function(data){
	
	$("span#submit_admin").html(data);
     
    });
    
}


//check for validity of the student form
function validate_student(){
	var check = new Boolean(true);
	if (!checkRegNum($("input#reg_numm").val())){
		$("div#regno").html("**");
		check = false;
	} else {
		$("div#regno").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if ($("input#surname").val()==""){
		$("div#lname").html("**");
		check = false;
	} else {
		$("div#lname").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if ($("input#first_name").val()==""){
		$("div#fname").html("**");
		check = false;
	} else {
		$("div#fname").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	if (!checkPhone($("input#phone").val())){
		$("div#phonediv").html("**");
		check = false;
	} else {
		$("div#phonediv").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	//if (isNaN($("input#level").val())){
	//	$("div#leveldiv").html("**");
	//	alert($("input#level").val());
	//	check = false;
	//} else {
	//	$("div#leveldiv").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	//}
	if (!checkEmail($("input#email").val())){
		$("div#emaildiv").html("**");
		check = false;
	} else {
		$("div#emaildiv").html("&nbsp;&nbsp;&nbsp;&nbsp;");
	}
	return check;
}

//check for validity of Email
function checkEmail(valemail){
	apos=valemail.indexOf("@");
	dotpos=valemail.lastIndexOf(".");
	if (apos<1||dotpos-apos<2||apos>dotpos){
		return false;
	} else {
		return true;
	}
}




//check for validity of Phone Number
function checkPhone(phone){
	var fonelenght = $("input#phone").val().length;
	if (fonelenght > 14)
		return false;
	if (fonelenght < 1)
		return false;
	for (var i=0; i<=fonelenght; i++){
		if (isNaN(phone.charAt(i))){
			return false;
		}
	}
	return true;
}

function checkCourseCode(courseCode){
	if (courseCode.length != 6){
		return false;
	} else {
		var lastPart = courseCode.substring(3,6);
		if (isNaN(lastPart)){
			return false;
		} else {
			return true;
		}
	}
}

//check for validity of sessions
function checkSession(asession){
	var firstPart = asession.substring(0,4);
	var slash = asession.charAt(4);
	var secondPart = asession.substring(5,9);
	alert(secondPart);
	if (slash != "/")
		return false;
	if (isNaN(firstpart))
		return false;
	if (isNaN(lastpart))
		return false;
	return true;
}

//check for validity of registration number
function checkRegNum(regNo){
	//var reglenght = $("input#reg_numm").val().length;
	reglenght = regNo.length;
	if (reglenght != 11){
		return false;
	}
	var firstpart = regNo.substring(0,4);
	var slash = regNo.charAt(4);
	var lastpart = regNo.substring(5,11);
	if (isNaN(firstpart))
		return false;
	if (isNaN(lastpart))
		return false;
	if (slash != "/")
		return false;
	return true;
}

//check for Empty fields
function isEmpty(value){
	if (value.lenght > 0)
		return true;
	else
		return false;
}


function load_active_session(count){
 	var course = $("#course"+count).val()
    //alert( " you are on number " + count + " of your list, you choosed " + course);
    $.post("ajax_calls.php",{course: course, load_session: true}, function(data){
	$("select#session" + count).html( data);
    });
}