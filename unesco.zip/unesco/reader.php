<?php require_once("./includes/initialize.php"); ?>

<?php   add_header($session->status); ?>
<center> <?php echo $session->message; ?></center>
<?php
    if(isset($_POST['filename'])){

   date_default_timezone_set('Europe/London');

   $file = $_POST['filename'];
   $table = strtolower($_POST['data_type']);
   $filename = "upload_files/".$_POST['filename'];


   $objPHPExcel = new PHPExcel();


   //$objReader = PHPExcel_IOFactory::createReader('Excel2007');
   $objReader = PHPExcel_IOFactory::createReader('Excel5');
   $objReader->setReadDataonly(true);
   
   $objPHPExcel = $objReader->load($filename);
   $objWorksheet = $objPHPExcel->getActiveSheet();
   
   echo '<table border = "1" cellpadding="6">'."\n";
   $outer = 1;
   foreach ($objWorksheet->getRowIterator() as $row){
      echo '<tr>'."\n";
	  
	  $cellIterator = $row->getCellIterator();
	  $cellIterator->setIterateOnlyExistingCells(false);
	  $data = array();
	  
	  foreach ($cellIterator as $cell) {
	    $data[] = $cell->getValue();
	     echo '<td>'. $cell->getValue() . '</td>' . "\n";
	  }
	  echo '</tr>' . "\n";
	  
	  // initializing variables for data importation into the database
	   $size = sizeof($data);
	   $treatment = $data[0];
	   $cyto = $data[3];
	   $auxin = $data[1];
	   $cyto_conc = $data[4];
	   $auxin_conc = $data[2];
	  if ($outer > 2){
	      for($index = 5; $index < $size; $index++){
	     $sql  = "insert into {$table} (treatment,cytokinin,auxin,cytokinin_conc,auxin_conc, value )";
	     
	     $sql .= "  values ( '{$treatment}',  '{$cyto}', '{$auxin}', '{$cyto_conc}', '{$auxin_conc}', '{$data[$index]}' )";
	     
	     $database->query($sql);
	      }
	      // input of row is complete at this point
	  }  
	  $outer++ ;  
   }
   echo '</table>' . "\n";

   $sqlone = "update files set status = 1 where filename = '".$file."'";
   $database->query($sqlone);
?>



<?php
// the class list reader ends here
    } else{
     redirect_to("./login.php");
     $session->message(" this could not be done because no file was found.");
    }
?>

<?php footer(); ?>
