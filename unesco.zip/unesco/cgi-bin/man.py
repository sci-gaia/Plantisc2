#!/usr/bin/env python
import cgi
import cgitb; cgitb.enable()
import os
import time, thread
import function 
import url_func 


# This line generates the header
g_func = function.general_func()
newline = g_func.newline
g_func.align_left()
content =  """
            This is the home pane 
    """
print content
print "</div>"
# This line generates the footer
g_func.footer()
