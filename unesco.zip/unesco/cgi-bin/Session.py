# -*- coding: cp1252 -*-
# Fig. 23.1: Session.py
# Contains a Session class that keeps track of an http session
# by assigning a session ID and pickling session information.

import os
import re
import md5
import cgi
import time
import urlparse
import os.path
import cPickle
from UserDict import UserDict

def getClientType():
    """Return the client type and file extension"""
    
    if re.search( "MSIE", os.environ[ "HTTP_USER_AGENT" ] ):
       return ( "html", "html" )
    elif re.search( "Netscape", os.environ[ "HTTP_USER_AGENT" ] ):
       return ( "html", "html" )
    elif re.search( "text/vnd.wap.wml",
       os.environ[ "HTTP_ACCEPT" ] ):
       return ( "wml", "wml" )
    else:
       return ( "html_basic", "html" )

def getContentType():
    """Return the contents of the client�s contentType file"""

    try:
       file = open( getClientType()[ 0 ] + "/contentType.txt" )
    except:
       raise SessionError( "Missing+content+type+file" )

    contentType = file.read()
    file.close()
    return contentType

def redirect( URL ):
    """Redirect the client to a relative URL"""
    
    print "Location: %s\n" % \
       urlparse.urljoin( "http://" + os.environ[ "HTTP_HOST" ] +
          os.environ[ "REQUEST_URI" ], URL )

class SessionError( Exception ):
    """User-defined exception for Session class"""

    def __init__( self, error ):
       """Set error message"""
       
       self.error = error

    def __str__( self ):
       """Return error message"""
       
       return self.error

class Session( UserDict ):
    """Session class keeps tracks of an HTTP session"""

    def __init__( self, createNew = 0 ):
       """Create a new session or load an existing session"""

       # attempt to load previously created session
       if not createNew:

          # session ID is passed in query string
          queryString = cgi.parse_qs( os.environ[ "QUERY_STRING" ] )

          # no ID has been supplied in query string
          if not queryString.has_key( "ID" ):
             raise SessionError( "No+ID+given" )
           
          self.sessionID = queryString[ "ID" ][ 0 ]
          self.fileName = os.getcwd() + "/sessions/." + \
             self.sessionID

          # supplied ID is invalid         
          if not self.sessionExists():
             raise SessionError( "Nonexistant+ID+given" )

          # load pickled session dictionary
          UserDict.__init__( self, self.loadSession() )

       # create new session
       else:
          self.sessionID = self.generateID()
          self.fileName = os.getcwd() + "/sessions/." + \
             self.sessionID

          if self.sessionExists():
             raise SessionError( "Session+already+exists" )

          UserDict.__init__( self )   # dictionary is empty

          # add ID, agent type, content type and empty cary to data
          self.data[ "ID" ] = self.sessionID 
          self.data[ "agent" ], self.data[ "extension" ] = \
             getClientType()
          self.data[ "content type" ] = getContentType()
          self.data[ "cart" ] = {}

    def sessionExists( self ):
       """Determine if the specified session file exists"""

       return os.path.exists( self.fileName )

    def loadSession( self ):
       """Return unpickled dictionary of existing session"""
       
       if self.sessionExists():
          sessionFile = open( self.fileName )
          data = cPickle.load( sessionFile )
          sessionFile.close()
          return data

    def saveSession( self ):
       """Pickle session dictionary to session file"""
       
       sessionFile = open( self.fileName, "w" )
       cPickle.dump( self.data, sessionFile )
       sessionFile.close()

    def deleteSession( self ):
       """Delete session file"""
       
       os.remove( self.fileName )

    def generateID( self ):
       """Use md5 to generate a unique ID"""
             
       seed = str( time.time() ) + os.environ[ "REMOTE_ADDR" ] + \
          os.environ[ "REMOTE_PORT" ]
       ID = md5.new( seed )
       return ID.hexdigest()
