#!/usr/bin/env python
import cgi, cgitb; cgitb.enable()
import function

g_func = function.general_func()
g_func.align_left()
newline = g_func.newline
p_tissue = function.plant_tissue()
form = cgi.FieldStorage()

print "<div style='font-size: 18px; text-align: center; font-weight: bold; color: #1133FF;'>"
if form:
    fm = function.form_processing(form)
    table = 'bud'
    table_root = 'root'
    table_height = 'height'
    table_leaf = 'leaf'
    
    treatment = fm.get_p('treatment')
    auxin_name = fm.get_p('auxin')
    auxin_conc = float(fm.get_p('auxin_conc'))
    cytokinin_name = fm.get_p('cytokinin')
    cytokinin_conc = float(fm.get_p('cytokinin_conc'))
    
    response = p_tissue.estimate_yeild(table, treatment, auxin_name, auxin_conc, cytokinin_name, cytokinin_conc)
    print 'Estimate yeild is ', response , '.<br /><br /><br />'
    
    #response_root = p_tissue.estimate_yeild(table_root, treatment, auxin_name, auxin_conc, cytokinin_name, cytokinin_conc)
    #print 'Estimate root is ', response_root , ',<br /><br /><br />'
    
    #response_height = p_tissue.estimate_yeild(table_height, treatment, auxin_name, auxin_conc, cytokinin_name, cytokinin_conc)
    #print 'Estimate plant height  is ', response_height , '.<br /><br /><br />'
    
    response_leaf = p_tissue.estimate_yeild(table_leaf, treatment, auxin_name, auxin_conc, cytokinin_name, cytokinin_conc)
    print 'Estimate leaf is ', response_leaf , ', thanks for using the application<br />.<br />'

    
else:
    print " Please use the application page to supply data "
    
print "<div>"

newline(); newline()
print """
     Done...
    """
print "</div>"
g_func.footer()





