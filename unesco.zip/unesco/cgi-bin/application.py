#!/usr/bin/env python
import cgi, os, time, cgitb; cgitb.enable()
import function, numpy


# This line generates the header
g_func = function.general_func()
newline = g_func.newline

def kinetin():
    data = numpy.arange(0.0, 11.0, 1.0)
    for value in data:
        print """<option value = "{0}">{1}</option>""".format(float(value), float(value))

def auxin():
    data = numpy.arange(0.0, 1.01, 0.05)
    for value in data:
        print """<option value = "{0}">{1}</option>""".format(value, value)


print   """<p>Enter the parameters you wish to apply <br /></p>
        <div style="width: 280px; height: auto;  padding: 5px 5px 5px 5px;">
        <form method = "post" action = "plant_tissue.py" name ="my_own">
        <p>
        <label style="float: left; margin-bottom: 5px;"> TREATMENT: </label>
        <select name = "treatment" style="float: right; margin-bottom: 5px;" />
          <option value = "AE">AE(1977)</option>
          <option value = "SH">SH(1972)</option>
        </select>
        <br />
        <br />
        </p>
        <p>
        <label style="float: left" ; margin-bottom: 5px;> CYTOKININ: </label>
        <select name = "cytokinin" style="float: right; margin-bottom: 5px;" />
          <option value = "KINETIN">KINETIN</option>
          <option value = "BAP">BAP</option>
        </select>
        <br />
        <br />
        </p>
        <p>
        <label style="float: left" ; margin-bottom: 5px;> CYTOKININ CONC. (mg): </label>
        <select name = "cytokinin_conc" style="float: right; margin-bottom: 5px;" />
        """
kinetin()
print   """
        </select>
        <br />
        <br />
        </p>
        <p>
        <label style="float: left" ; margin-bottom: 5px;> AUXIN: </label>
        <select name = "auxin" style="float: right; margin-bottom: 5px;" />
          <option value = "NAA">NAA</option>
        </select>
        <br />
        <br />
        </p>
        <p>
        <label style="float: left" ; margin-bottom: 5px;> AUXIN CONC. (mg): </label>
        <select name = "auxin_conc" style="float: right; margin-bottom: 5px;" />
        """
auxin() 
print   """
        </select>
        <br />
        <br />
        </p>
        <p><br />
        <input type = "submit" value = "Estimate" style = "float:right;"/>
        </p>
        </form>
        </div>
        """

    
newline()

# This line generates the footer
g_func.footer()