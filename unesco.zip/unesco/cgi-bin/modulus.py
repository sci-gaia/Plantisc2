#!/usr/bin/env python
import cgi
import cgitb; cgitb.enable()
import os
import time, thread
import function
import url_func
from subprocess import PIPE


# This line generates the header
g_func = function.general_func()
newline = g_func.newline
g_func.align_left()
content =  """
            This is the home pane, that has never been tested. Thanks to God Almighty.
    """
print content
print "</div>"

# This line generates the footer
g_func.footer()
