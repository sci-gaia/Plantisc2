import MySQLdb as db
from numpy import *
import sys, time, os, cgi, urlparse


class general_func:
    def __init__(self):    
        self.conn = db.connection("localhost", "root", "crying", "unesco");
        
        
        print('Content-type: text/html\n')
        print # Print an empty line to end the  headers

        print """
           <html>
          <head>
            <title>UNESCO-HP-UNN</title>
            <script type="text/javascript" src="../scripts/jquery.js" ></script>
                <script type="text/javascript" src="../scripts/jquery-ui-1.8.14.custom.min.js" ></script>
            <link href="../stylesheets/main.css" media="all" rel="stylesheet" type="text/css" />
                <link href="../stylesheets/jquery-ui-1.8.14.custom.css" media="all" rel="stylesheet" type="text/css" />
          </head>
          <body>
            <script type="text/javascript" src="../scripts/javascript.js"></script>
           <center>
           <div  style="width: 960px; margin-left: auto; margin-right: auto;"> 
           <table id="main_table" style=" height: 700px;">
              <tr>
                     <td id="header">
           
              <div class="mid"> <img src="../images/unesco.jpg"  class="logo"/><span style="font-size: 20px; font-weight: bold;"> UNESCO-HP-UNN PROJECT</span></div>
                     </td>
                  </tr>
                       <tr>
                        <td id='link_tab'>
                          <a href='../cgi-bin/index.py'>Home</a>&nbsp;&nbsp;&nbsp;|
                          <a href='../cgi-bin/application.py'>Application</a> &nbsp;&nbsp;&nbsp;|
                          <a href='../admin.php'>Admin</a>&nbsp;&nbsp;&nbsp;|
                          <a href='http://grid.unn.edu.ng'>Main Site</a>&nbsp;&nbsp;&nbsp;
                         </td>
                       </tr>
                      
                   
                 
                  
                  <tr>
                     <td id="main">
            <center>
            
            """
    def main_page(self):
        cur = self.conn.cursor(db.cursors.DictCursor)
        sql = "SELECT * FROM bud  WHERE cytokinin = '%s' \
                and cytokinin_conc = %f \
                and auxin = '%s' \
                and auxin_conc = %f \
                "  % ('KINETIN', 2.00, 'NAA', 0.5)
                 
        cur.execute(sql)
        data = cur.fetchall()
        
        #print table_th
        # creating list to hold values for matrix operation X_1 = cytokinin, X_2 = auxin, Y_1 = response value
        X_1 = []
        X_2 = []
        Y_1 = []
        unity = []
        for row in data:
            data_value = float(row["value"])
            auxin_data = float(row["auxin_conc"])
            cytokinin_data = float(row["cytokinin_conc"])
            
            Y_1.append(cytokinin_data)
            X_1.append(auxin_data)
            X_2.append(data_value)
            unity.append(1.0)
            
        
        cur.close()
        table_end = """
            </table>
            <br />
        """

        #print table_end
        # More display contents

        
        print Y_1, '<br />', X_1, '<br />',X_2, '<br />', unity

        print '<br />', '<br />'

        init_value = matrix([unity, X_1, X_2])

        mat_X = init_value.T

        print mat_X , '<br />', '<br />'
        print matrix(Y_1).T, '<br />'
        print 'done printing matrix of Y'
        
     
    def footer(self):
        # this is the footer for the document
        print """
            </center>
                   </td>
                 </tr>
                 <tr>
                    <td>
            <div id="footer">&copy; %s, Lion Grid- University of Nigeria, Nsukka.</div>
                    </td>
                  </tr>
                 </table>
                  </div> 
                 </center>
          </body>
        </html>

            """ % self.this_year()
        self.conn.close()

    def redirect(self, URL ):
        """Redirect the client to a relative URL"""
    
        print "Location: %s\n" % \
           urlparse.urljoin( "http://" + os.environ[ "HTTP_HOST" ] +
              os.environ[ "REQUEST_URI" ], URL )
        sys.exit


    def newline(self):
        print "<br />"

    def align_left(self):
        print "<div style='text-align: left;'>"

    def this_year(self):
        time_string = time.ctime()
        time_list = time_string.split()
        return str(time_list[-1])

    def is_post(self):
        if os.environ['REQUEST_METHOD'] == 'POST':
            return True
        return False




# A new class to handle the operations involved in plant tissue    
class plant_tissue:
    """ This class handles all the methods needed to process
        the estimation of yeild in the plant tissue culture
        """

    def __init__(self):
        self.conn = db.connect("localhost", "root", "crying", "unesco");

    def __del__(self):
        self.conn.close()

    def estimate_yeild(self, table, treatment, auxin_name, auxin_conc, cytokinin_name, cytokinin_conc, est_error = 0):
        """ This method uses both get_coefficient and estimate_response methods
            to return the estimated yeild based on the desired output
            """
        coefficient = self.get_coefficient(table, treatment, auxin_name, cytokinin_name)
        estimate_value = self.estimate_response(auxin_conc, cytokinin_conc, coefficient, est_error)
        
        
        return estimate_value
    

    def get_coefficient(self, table, treatment, auxin_name, cytokinin_name):
        """ This method pulls data from the database and uses it to generate a matrix
            which it processes and returns a list coefficient
            """
        cur = self.conn.cursor(db.cursors.DictCursor)
        sql = """SELECT * FROM  {0}  
                WHERE treatment = '{1}' 
                AND cytokinin = '{2}' 
                AND auxin = '{3}' 
                """.format(table, treatment, cytokinin_name, auxin_name)
                 
        cur.execute(sql)
        data = cur.fetchall()
    
        # creating list to hold values for matrix operation X_1 = cytokinin, X_2 = auxin, Y_1 = response value
        auxin = []
        cytokinin = []
        yeild = []
        unity = []
        for row in data:
            yeild_data = float(row["value"])
            auxin_data = float(row["auxin_conc"])
            cytokinin_data = float(row["cytokinin_conc"])
            
            auxin.append(auxin_data)
            cytokinin.append(cytokinin_data)
            yeild.append(yeild_data)
            unity.append(1.0)
            
        
        cur.close()

       
        mat_X = matrix([unity, auxin, cytokinin]).T
        mat_Y = matrix(yeild).T

        first_part = (mat_X.T * mat_X)
        first_part_inv = first_part.I
        second_part = (mat_X.T * mat_Y)

        coeff_mat = first_part_inv * second_part
        coeff_arr  = coeff_mat.A
        coeff = [float(x) for x in coeff_arr]
        print "Generating trace of execution...<br /><br />"
        
        print "The size of the data is... ", len(unity), "<br /><br />"
        
        return coeff

    def estimate_response(self, auxin_conc, cytokinin_conc, coefficient, est_error):
        """ This method computes the estimated response using data obtained from
            get_coefficient to implement basic linear regression
            """
        response = coefficient[0] + (coefficient[1] * auxin_conc) + (coefficient[2] * cytokinin_conc) + est_error
        return response
    

class form_processing:
    """Easy processing of form parameters and use"""

    def __init__(self, form):
        self.form = form
        self.parameter = {}
        self.fields =  form.keys()
        self.set_p(self.fields)
       
        

    def set_p(self, name, default_value = None):
        """ Register a new parameter, or a list of parameters """
        if isinstance(name, list):
            for key in name:
                self.parameter[key] = default_value
        else:
            self.parameter[name] = default_value

    def get_p (self, name, multiple = False):
        """Return the value of the form parameter"""
        if name in self.form:
            if multiple:
                self.parameter[name] = self.form.getlist(name)
            else:
                self.parameter[name] = self.form.getfirst(name)    
            
        if name in self.parameter:
            return cgi.escape(self.parameter[name])
        else:
            return "No variable with name {0}".format(name)
