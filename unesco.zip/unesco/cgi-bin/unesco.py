#!C:\Python27\python.exe
#from function import general_func as fn
import cgitb; cgitb.enable()
import function 

g_func = function.general_func()
newline = g_func.newline

# this is where the body of the code is meant to be

g_func.main_page()
print

newline(); newline()
print """
     Thank God I got this far
    """
g_func.footer()





