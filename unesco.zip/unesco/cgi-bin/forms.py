#!/usr/bin/env python
import cgi
import os
import time
import cgitb; cgitb.enable()
import function 
import url_func

# This line generates the header
g_func = function.general_func()
newline = g_func.newline
form = cgi.FieldStorage()
form_1 =  """<p>Enter one of your favourite words here: <br /></p>
        <div style="width: 250px; height: auto;  padding: 5px 5px 5px 5px;">
        <form method = "post" action = "forms.py" name ="my_own">
        <p>
        <label style="float: left; margin-bottom: 5px;"> Lastname: </label>
        <input type = "text" name = "lastname" style="float: right; margin-bottom: 5px;" /><br />
        </p>
        <p>
        <label style="float: left" ; margin-bottom: 5px;> Firstname: </label>
        <input type = "text" name = "firstname" style="float: right;  margin-bottom: 5px;"  /><br />
        </p>
        <p>
        <label style="float: left" ; margin-bottom: 5px;> State: </label>
        <input type = "text" name = "state" style="float: right;  margin-bottom: 5px;"  /><br />
        </p>
        <p><br />
        <input type = "submit" value = Submit word" style = "float:right;"/>
        </p>
        </form>
        </div>
        """

if  form:
    fm = function.form_processing(form)
    for key in fm.fields:
        print "Your {0} is {1}".format(key, fm.get_p(key)), " with type "
        print type(fm.get_p(key))
        newline()
        
        
        
else:
  # print form_1
  print "";
    
newline();newline()

# This line generates the footer
g_func.footer()