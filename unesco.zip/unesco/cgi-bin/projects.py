#!C:\Python27\python.exe
#from function import general_func as fn
import cgi
import os
import time
import cgitb; cgitb.enable()
import function 
import url_func 

# This line generates the header
g_func = function.general_func()
newline = g_func.newline

print "hello to all the new commers!"

newline()
print url_func.getBaseURL()
newline()

print 'have a nice day'
newline()
print time.ctime( time.time())
newline(); newline()
query = os.environ['QUERY_STRING']

if len(query) == 0:
    print """<p><br />
        please add some name-value pairs
        or try
        <a href = 'projects.py?name=modulus;age=24'>this</a>
        </p>"""
else:
    print """ <p style = "font-style: italic">
     The query string is '%s'.</p>""" % cgi.escape(query)
    pairs = cgi.parse_qs(query)

    for key, value in pairs.items():
        print "<p> you set '%s'  to value %s</p>" % (key, value)


variables = os.environ.keys()
for i in variables:
    print i
    newline()
    
# This line generates the footer
g_func.footer()





