#!/usr/bin/env python
import cgi
import cgitb; cgitb.enable()
import os
import time, thread
import function 
import url_func 


# This line generates the header
g_func = function.general_func()
newline = g_func.newline
g_func.align_left()
content =  """
            <div style="font-size: 18px; text-align: center; font-weight: bold; color: #1133FF;">
                This is the home pane, for the application.
                <br /><br />
                
                You can continue to the application page and run your tests.
            </div>
            <div>
            
            </div>
    """
print content
print "</div>"
# This line generates the footer
g_func.footer()
