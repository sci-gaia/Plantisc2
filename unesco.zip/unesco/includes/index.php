<?php require_once("./includes/initialize.php");  ?>
<?php  redirect_to("login.php");  ?>
