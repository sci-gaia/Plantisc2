<?php


class Session {
	
	private $logged_in=false;
	public $admin_id;
	public $username;
	public $password;
	public $surname;
	public $first_name;
	public $message;
	public $status;
	
	
	function __construct() {
		session_start();
		$this->check_message();
		$this->check_login();
    if($this->logged_in) {
      // actions to take right away if user is logged in
      $this->status = true;
    } else {
      // actions to take right away if user is not logged in
      $this->status = false;
    }
	}
	
  public function is_logged_in() {
    return $this->logged_in;
  }
  
  public function full_name() {
    if(isset($this->first_name) && isset($this->surname)) {
      return $this->surname . " " . $this->first_name;
    } else {
      return " ";
    }
  }
  
  
  
  
	public function login($user) {
    // database should find user based on username/password
    if($user){
      $this->admin_id = $_SESSION['admin_id'] = $user->id;
       $_SESSION['li_username'] = $user->username;
       $_SESSION['li_surname'] = $user->surname;
       $_SESSION['li_first_name'] = $user->first_name;
      $this->logged_in = true;
    }
  }
  
  public function not_active(){
	
        if(($this->active != 1) || ($this->active_date != true)) {
		return true;
		} else { return false;} 
  }
  

  
  
  public function instantiate(){
	if(isset($_SESSION['admin_id'])){
       $this->username = $_SESSION['li_username'] ;
       $this->surname = $_SESSION['li_surname'] ;
       $this->first_name = $_SESSION['li_first_name'];
	} else {
		
	}
  }
  
  
  public function logout() {
    global $database;
    
    unset($_SESSION['grant_access']);
    unset($_SESSION['admin_id']);
    unset($this->admin_id);
    $this->logged_in = false;
  }

	public function message($msg="") {
	  if(!empty($msg)) {
	    // then this is "set message"
	    // make sure you understand why $this->message=$msg wouldn't work
	    $_SESSION['message'] = "<span style='color: red'>  ".$msg." </span><br /><br />";
	  } else {
	    // then this is "get message"
			return $this->message;
	  }
	}

	private function check_login() {
    if(isset($_SESSION['admin_id'])) {
      $this->admin_id = $_SESSION['admin_id'];
      $this->logged_in = true;
    } else {
      unset($this->admin_id);
      $this->logged_in = false;
    }
  }
  
	private function check_message() {
		// Is there a message stored in the session?
		if(isset($_SESSION['message'])) {
			// Add it as an attribute and erase the stored version
      $this->message = $_SESSION['message'];
      unset($_SESSION['message']);
    } else {
      $this->message = "";
    }
	}
	
}

$session = new Session();
$message = $session->message();
$init = $session->instantiate();

?>