<?php

function strip_zeros_from_date( $marked_string="" ) {
  // first remove the marked zeros
  $no_zeros = str_replace('*0', '', $marked_string);
  // then remove any remaining marks
  $cleaned_string = str_replace('*', '', $no_zeros);
  return $cleaned_string;
}




function redirect_to( $location = NULL ) {
  if ($location != NULL) {
    header("Location: {$location}");
    exit;
  }
}

function output_message($message="") {
  if (!empty($message)) { 
    
	return "<p class=\"message\">{$message}</p>";
  } else {
    return "";
  }
}

function __autoload($class_name) {
	$class_name = strtolower($class_name);
  $path = LIB_PATH.DS."{$class_name}.php";
  if(file_exists($path)) {
    require_once($path);
  } else {
		die("The file {$class_name}.php could not be found.");
	}
}

function include_layout_template($template="") {
	include(SITE_ROOT.DS.'layouts'.DS.$template);
}

function log_action($action, $message="") {
	$logfile = SITE_ROOT.DS.'logs'.DS.'log.txt';
	$new = file_exists($logfile) ? false : true;
  if($handle = fopen($logfile, 'a')) { // append
    $timestamp = strftime("%Y-%m-%d %H:%M:%S", time());
		$content = "{$timestamp} | {$action}: {$message}\n";
    fwrite($handle, $content);
    fclose($handle);
    if($new) { chmod($logfile, 0755); }
  } else {
    echo "Could not open log file for writing.";
  }
}

function datetime_to_text($datetime="") {
  $unixdatetime = strtotime($datetime);
  return strftime("%B %d, %Y at %I:%M %p", $unixdatetime);
}

function add_header($status = false){
?>
<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Transitional//EN"
"http://www.w3.org/TR/xhtml1/DTD/xhtml1-transitional.dtd">
<html>
  <head>
    <title>UNESCO-HP-UNN</title>
    <script type="text/javascript" src="scripts/jquery.js" ></script>
	<script type="text/javascript" src="scripts/jquery-ui-1.8.14.custom.min.js" ></script>
    <link href="stylesheets/main.css" media="all" rel="stylesheet" type="text/css" />
	<link href="stylesheets/jquery-ui-1.8.14.custom.css" media="all" rel="stylesheet" type="text/css" />
  </head>
  <body>
    <script type="text/javascript" src="scripts/javascript.js"></script>
   <center>
    <div  style="width: 960px; margin-left: auto; margin-right: auto;"> 
   <table id="main_table" style=" height: 700px;">
      <tr>
	     <td id="header" >
   
      <div class="mid"> <img src="images/unesco.jpg"  class="logo"/><span style="font-size: 20px; font-weight: bold;"> UNESCO-HP-UNN PROJECT </span></div>
	     </td>
	  </tr>
	       <tr>
	        <td id='link_tab'>
		  <a href='index.php'>Home</a>&nbsp;&nbsp;&nbsp;|
		  <a href='./cgi-bin/application.py'>Application</a> &nbsp;&nbsp;&nbsp;|
		  <a href='admin.php'>Admin</a>&nbsp;&nbsp;&nbsp;|
		  <a href='http://grid.unn.edu.ng'>Main Site</a>&nbsp;&nbsp;&nbsp;
		  <?php if ($status == true) {?>
		  <a href='logout.php' style="float:right; margin-right: 10px;">logout</a>&nbsp;&nbsp;&nbsp;
		  <?php } ?>
		 </td>
	       </tr>
	      
	   
	 
	  
	  <tr>
	     <td id="main">
    
<?php 
}



function footer(){
 ?>
	   </td>
	 </tr>
	 <tr>
	    <td>
    <div id="footer">&copy; <?php echo date("Y", time()); ?>, Lion Grid- University of Nigeria, Nsukka.</div>
	    </td>
	  </tr>
	 </table>
    </div>
	 </center>
  </body>
</html>
<?php if(isset($database)) { $database->close_connection(); } 
}

function getExtension($str) {
	 $i = strrpos($str,".");
	 if (!$i) { return ""; }
	 $l = strlen($str) - $i;
	 $ext = substr($str,$i+1,$l);
	 return $ext;
}

function filter($value) {
	if(get_magic_quotes_gpc())
		$value = stripslashes($value);
	if(!is_numeric($value))
		$value = mysql_real_escape_string($value);
	$value = htmlspecialchars($value);
	return trim($value);
}
?>
