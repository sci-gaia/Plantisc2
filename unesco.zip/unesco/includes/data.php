<?php
// If it's going to need the database, then it's 
// probably smart to require it before we start.
require_once(LIB_PATH.DS.'database.php');

class Data  {
	
   
   public static function get_treatment_id($name){
	global $database;
	$result = $database->query(" SELECT  surname, first_name FROM treatment   WHERE name = '".$name."'  LIMIT 1");
	$admin = $database->fetch_array($result);
	return $admin['id'];
   }
   
  
  
     
}

?>