<?php require_once("./includes/initialize.php"); ?>
<?php //if (!$session->is_logged_in()) { redirect_to("login.php"); };
?>
<?php
	$max_file_size = 1048576;
	$data_array = array('Bud' , 'Height', 'Leaf', 'Root');

	if(isset($_POST['submit'])) {
		if(empty($_POST['data_type'])){
			$session->message("The Data Type field was empty.");
			redirect_to('upload.php');	
		}
		$result = new Upload();
		$result->caption = $_POST['caption'];
		$result->data_type = $_POST['data_type'];
		$result->upload_date = date('Y-m-d H:i:s');
		$result->username = $session->username;
		$result->attach_file($_FILES['file_upload']);
	
		if($result->save()) {
			// Success
      $session->message("File  uploaded successfully.");
			redirect_to('files.php');
		} else {
			// Failure
      $message = join("<br />", $result->errors);
		}
	}
	
?>

<?php   add_header($session->status); ?>
	<center><h1>DATA UPLOAD</h1></center>

	
	<center><h3><?php echo output_message($message); ?></h3></center>
  <br /><br /><br /><br />
  <center>
	<div style="border: solid 1px blue; width: 450px; padding-bottom: 20px;">
  <form action="upload.php" enctype="multipart/form-data" method="POST">
    <input type="hidden" name="MAX_FILE_SIZE" value="<?php echo $max_file_size; ?>" />
    <p><input type="file" name="file_upload" /></p>
    <p>Caption<input type="text" name="caption" value="" /></p>
    <p>Data Type
       <select name="data_type">
          <option value=""></option>
	  <?php
	   for($i = 0; $i < sizeof($data_array); $i++){
	       echo "<option value='".$data_array[$i]."'>".$data_array[$i]."</option>";
	   }
          
	  ?>
	</select>
    </p>
	
       <br /><br />
    
    <input type="submit" name="submit" value="Upload" />
    
  </form>
	</div>
  </center>

<?php footer(); ?>
		
