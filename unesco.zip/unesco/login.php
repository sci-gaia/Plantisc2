<?php
require_once("./includes/initialize.php");

if($session->is_logged_in()) {
  redirect_to("admin.php");
}

// Remember to give your form's submit tag a name="submit" attribute!
if (isset($_POST['submit'])) { // Form has been submitted.

  $username = trim($_POST['username']);
  $password = md5(trim($_POST['password']));
  //$password = trim($_POST['password']);
  
  // Check database to see if username/password exist.
	$found_user = Admin::authenticate($username, $password);
	
  if ($found_user) {
	//die("checking trend of processes");
       $session->login($found_user); 
       $session->instantiate(); 
       redirect_to("admin.php");
    
  } else {
    // username/password combo was not found in the database
    $message = "Username and password do not match, try again or contact an Administrator.";
  }
  
} else { // Form has not been submitted.
  $username = "";
  $password = "";
}

?>
<?php   add_header($session->status); ?>

		<center>
		<h2>ADMINISTRATIVE USE ONLY</h2>
		<span style="font-size: 13px; font-style: italic; color: red;"><?php echo output_message($message); ?></span>

		<form action="login.php" method="post">
		  <table cellpadding="10">
		    <tr>
		      <td>Username:</td>
		      <td>
		        <input type="text" name="username" maxlength="30" value="<?php echo htmlentities($username); ?>" />
		      </td>
		    </tr>
		    <tr>
		      <td>Password:</td>
		      <td>
		        <input type="password" name="password" maxlength="30" value="" />
		      </td>
		    </tr>
		    <tr>
		      <td colspan="2">
		        <center><input type="submit" name="submit" value="Login" /></center>
		      </td>
		    </tr>
		  </table>
		</form>
		</center>

<?php footer(); ?>
