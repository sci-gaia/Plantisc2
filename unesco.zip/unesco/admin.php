<?php
   require_once("./includes/initialize.php");
?>
<?php
   if (!$session->is_logged_in()) {redirect_to("./login.php"); };
?>

<?php   add_header($session->status); ?>

 <center>
 <table style="width: 96%; height: 80%;">
    <tr  style=" ">
     <td style="width:180px; height: auto;">
	  <div style="margin: 30px 1px 40px 10px;">
	   <div class="my_link" > <a href="upload.php" > New Upload </a> </div>
           <div class="my_link" > <a href="files.php" > File List </a> </div>
	  </div>
     </td>
     <td style="padding-left: 10px;">
	   
	   <div  style="width: 660px; margin-left: auto; margin-right: auto; padding-top: 30px;"> 
	      this is where the admin should perform all exclusive functions
	   </div>
	   
	 
     </td>
    </tr>
 </table>
 </center>

<?php footer();
?>
