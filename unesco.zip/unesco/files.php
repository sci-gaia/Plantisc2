<?php require_once("./includes/initialize.php");  ?>
<?php //if (!$session->is_logged_in()) { redirect_to("login.php"); };
?>
<?php
  // Find all the results
  $results = Upload::find_all_files();
  // retrieving all valid sessions
    
    
  
  
  
  
?>
<?php    add_header($session->status); ?>
<center>
  <h2>All Data files</h2>

  <?php echo $session->message; ?>
  <table class="st" >
  <tr style='border: 1px solid '>
    <th style='border: 1px solid; '>Upload Date</th>
    <th style='border: 1px solid ;'>Filename</th>
    <th style='border: 1px solid ;'>Caption</th>
    <th style='border: 1px solid ;'>Data Type</th>
    <th style='border: 1px solid ;'>Size</th>
    <th style='border: 1px solid ;'>Upload By</th>
    <th style='border: 1px solid ;' >Save</th>
    <th style='border: 1px solid ;'>Status</th>
  </tr>
  <?php   $count = 1;  ?>
<?php foreach($results as $result): ?>
  <tr style='border: 1px solid;'>
    <form name="save_file<?php echo $count; ?>" action="reader.php" method="post">
    <td style="padding: 3px 8px; "><?php echo $result->upload_date; ?></td>
    <td style="padding: 3px 8px; "><?php echo $result->filename;?></td>
    <td style="padding: 3px 8px; "><?php echo $result->caption; ?></td>
    <td style="padding: 3px 8px; "><?php echo $result->data_type; ?></td>
    <td style="padding: 3px 8px; "><?php echo $result->size_as_text(); ?></td>
    <td style="padding: 3px 8px; "><?php echo $result->username; ?></td>
    
    <td style="padding: 3px 8px;">
      <input type="submit" name="save" value="save"  <?php if($result->status == 1) echo "disabled='disabled'"; ?> />
      <input type="hidden" name="filename" value="<?php echo $result->filename; ?>" />
      <input type="hidden" name="data_type" value="<?php echo $result->data_type; ?>" />
    </td>
    <td style="padding: 3px 8px;"><input type="checkbox" name="status" disabled="disabled"  <?php if($result->status == 1) echo "checked='checked'"; ?> /></td>
    </form>
  </tr>
  <?php  $count++; ?>
<?php endforeach; ?>
</table>
<br />
<a href="upload.php">Upload a new file</a>
</center>
<?php footer(); ?>
