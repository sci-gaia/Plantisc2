<?php require_once("./includes/initialize.php");  ?>
<?php  redirect_to(BASE_URL."login.php");  ?>
