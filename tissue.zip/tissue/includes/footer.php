<div id="footer">
<br>
	<p>Copyright &copy UNESCO-HP-UNN Project <a href="#">Tissue Culture</a></p>
	
</div> <!-- end #footer -->
