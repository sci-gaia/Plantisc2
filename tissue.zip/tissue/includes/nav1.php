
<div id="nav">
<link href="css/dropdown/dropdown.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/dropdown/themes/default/default.css" media="screen" rel="stylesheet" type="text/css" />
	<ul id="nav" class="dropdown dropdown-horizontal">
		<li><a class="" href="http://localhost/tissue/homepage.php">Home</a> </li>
			<li><a class="" href="http://localhost/tissue/download.php">Download Data</a> </li>
		<li><a class="" href="http://localhost/tissue/upload.php">Upload Data</a> </li>
		<li><a class="" href="http://localhost/tissue/predict.php">Predict</a> </li>
	<li><a class="" href="http://localhost/tissue/simulate.php">Simulate</a> </li>
		<li><a class="" href="http://localhost/tissue/print.php">Print Result</a> </li>
		<li><a class="" href="http://localhost/tissue/export.php">Export Data</a> </li>
		<li><a class="" href="http://localhost/tissue/index.php">Logout</a> </li>
	
</div> <!-- end #nav -->


