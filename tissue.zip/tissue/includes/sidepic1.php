<div id="sidebar">

<li><h3><a>Tedious</a></h3><li>
<align = "center"><img src=" http://localhost/tissue/images1/tedious.jpg" align="center" />
<li><h3><a>Cost</a></h3><li>
<align = "center"><img src=" http://localhost/tissue/images1/cost.jpg" align="center" />
<li><h3><a>Time</a></h3><li>
<align = "center"><img src=" http://localhost/tissue/images1/time.jpg" align="center" />
<li><h3><a>Prediction</a></h3><li>
<align = "center"><img src=" http://localhost/tissue/images1/predict.jpg" align="center" />
</div> <!-- end #sidebar -->
