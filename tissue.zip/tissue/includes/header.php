<div id="header h2">
<align = "centre"><img src=" http://localhost/tissue/images1/lin.jpg" align="centre" />
<center><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#ffffff">
      <tr>
	  
        <td>
<align = "left"><img src=" http://localhost/tissue/images1/logo1.jpg" align="left" />
<align = "right"><img src=" http://localhost/tissue/images1/logo1.jpg" align="right" />
<align = "centre"><img src=" http://localhost/tissue/images1/log.jpg" align="centre" />			
				
     
       </tr>
        <td>
		
	
	 
   </table>
</div> <!-- end #header -->
<div id="header">
<center><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="#330033">
       <td>
		<p align="center"><b><font face="Times New Roman" >
	   <strong><font size="6" color="#ffffff"><i><center>Tissue Culture Made Easy!!<center></i> </font> 
</td>	  	  
		  </table>

	</div> <!-- end #header -->
