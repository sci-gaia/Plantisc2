<div id="nav">
<link href="css/dropdown/dropdown.css" media="screen" rel="stylesheet" type="text/css" />
<link href="css/dropdown/themes/default/default.css" media="screen" rel="stylesheet" type="text/css" />
	<ul id="nav" class="dropdown dropdown-horizontal">
	<li><a class="" href="http://localhost/tissue/index.php">Home</a> </li>
	<li><a class="" href="http://localhost/tissue/register.php">Register</a> </li>
		<li><a class="" href="http://localhost/tissue/userlogin.php">Login</a> </li>
		<li><a class="" href="http://localhost/tissue/guide.php">Instructions</a> </li>
		<li><a class="" href="http://localhost/tissue/temp.php">Template</a> </li>
</ul>

</div> <!-- end #nav -->

