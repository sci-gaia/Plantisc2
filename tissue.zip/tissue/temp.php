<!DOCTYPE html PUBLIC "-//W3C//DTD XHTML 1.0 Strict//EN" "http://www.w3.org/TR/xhtml1/DTD/xhtml1-strict.dtd">

<html xmlns="http://www.w3.org/1999/xhtml" xml:lang="en" lang="en">

<head>

<meta http-equiv="content-type" content="text/html; charset=utf-8" />

<meta name="description" content="" />

<meta name="keywords" content="" />

<meta name="author" content="" />

<link rel="stylesheet" type="text/css" href="style1.css" media="screen" />

<title>Tissue Culture Portal</title>

</head>

	<body>

		<div id="wrapper">

<?php include('includes/header.php'); ?>
<?php include('includes/nav.php'); 
?>

<center><table width="100%" border="0" cellpadding="0" cellspacing="0" bgcolor="330033">
      <tr>
        <td>
		<p align="center"><b><font face="Times New Roman" color="#ffffff">
		<marquee><?php echo " CLICK TO DOWNLOAD THE DESIRED FILE.";?></marquee></font></b></td>

      </tr>
       <tr>
        <td>
		
	</tr>
	 
   </table>
<br></br>

 	  <h3><font color ="#727b84"><a href="http://localhost/tissue/data.xls" ><font color="#727b84">Click to Download Template</font></a></h2>
	  	  
	  </tr>
     
          
</body>

</div> <!-- end #content -->